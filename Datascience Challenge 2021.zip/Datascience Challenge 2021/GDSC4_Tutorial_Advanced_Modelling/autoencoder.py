from tensorflow import keras
from tensorflow.keras import layers
import argparse
import os
import json

from tensorflow.keras.utils import Sequence
import numpy as np
import pandas as pd
import math
from pathlib import Path
import itertools
import boto3


def model(x_train, x_test, epochs, window_size, feature_dim, batch_size=1):
    """Generate a simple model"""
    
    input_data = keras.Input(shape=(window_size, feature_dim, 1), batch_size=batch_size)

    x = layers.Conv2D(16, (4, 4), activation='relu', padding='same')(input_data)
    x = layers.MaxPooling2D((2, 2), padding='same')(x)
    x = layers.Conv2D(8, (4, 4), activation='relu', padding='same')(x)
    x = layers.MaxPooling2D((2, 2), padding='same')(x)
    x = layers.Conv2D(8, (4, 4), activation='relu', padding='same')(x)
    encoded = layers.MaxPooling2D((2, 2), padding='same')(x)

    # at this point the representation is (4, 4, 8) i.e. 128-dimensional

    x = layers.Conv2D(8, (4, 4), activation='relu', padding='same')(encoded)
    x = layers.UpSampling2D((2, 2))(x)
    x = layers.Conv2D(8, (4, 4), activation='relu', padding='same')(x)
    x = layers.UpSampling2D((2, 2))(x)
    x = layers.Conv2D(16, (4, 4), activation='relu', padding='same')(x)
    x = layers.UpSampling2D((2, 2))(x)
    decoded = layers.Conv2D(1, (4, 4), activation='sigmoid', padding='same')(x)

    autoencoder = keras.Model(input_data, decoded)
    autoencoder.summary()
    autoencoder.compile(optimizer=keras.optimizers.Adam(learning_rate=0.001), loss='mse')

    autoencoder.fit(x_train, epochs=epochs, validation_data=x_test)

    return autoencoder


class DataGeneratorFromCSV(Sequence):
    def __init__(self, file_names, window_size, feature_dim, batch_size, default_s3_location="data/ek60/tabular"):
        self.file_names = file_names
        self.s3_location = default_s3_location
        self.window_size = window_size
        self.feature_dim = feature_dim
        self.batch_size = batch_size
        self.local_meta_info_path = Path("meta_info")
        self.local_meta_info_path.mkdir(parents=True, exist_ok=True)
        
        self.record_book = self.setup_record_book(file_names, default_s3_location)
        
        self.total_number_of_records = len(self.record_book)
    
    @staticmethod
    def setup_record_book(file_names, s3_location):
        
        for file_name in file_names:
            DataGeneratorFromCSV.download_file(
                "gdsc4-eu", 
                f"{s3_location}/meta_info_{file_name.stem}.txt", 
                Path.cwd()
            )
        file_infos = {
            file_name: DataGeneratorFromCSV.extract_number_of_records(
                Path(Path.cwd(), f"meta_info_{file_name.stem}.txt")
            ) for file_name in file_names
        }
        total_number_of_records = sum(file_infos.values())

        record_table = {
            'overall_record_id': [entry for entry in range(0, total_number_of_records)],
            'file_record_id': list(itertools.chain.from_iterable(
                [range(0, file_infos[file_name]) for file_name in file_infos.keys()]
            )),
            'file_name': list(itertools.chain.from_iterable(
                [itertools.repeat(file_name, file_infos[file_name]) for file_name in file_infos.keys()]
            )),
        }
        record_book = pd.DataFrame.from_dict(record_table)         
        return record_book.set_index('overall_record_id')
        
        
    def __len__(self):
        return math.floor(
            self.total_number_of_records / (self.batch_size * self.window_size)
        ) - 1
    
    def __getitem__(self, index):
        from_record = index * self.batch_size * self.window_size
        to_record = (index + 1) * self.batch_size * self.window_size
        csv_files = self.record_book[from_record:to_record]["file_name"].unique()
        from_record_info = self.record_book.iloc[from_record]
        to_record_info = self.record_book.iloc[to_record]
        
        if len(csv_files) == 1:
            df = pd.read_csv(from_record_info.file_name)
            df = df[from_record_info.file_record_id:to_record_info.file_record_id]
            batch = self.perform_preprocessing(df)
            batch = batch.reshape([self.batch_size, self.window_size, self.feature_dim, 1])
        else:
            data_collection = []
            for csv_file in csv_files:
                data = pd.read_csv(csv_file)
                data.columns = [f"{el}" for el in range(0, data.shape[1])] # enforce exactly matching column names
                if csv_file == csv_files[0]:
                    data = data[from_record_info.file_record_id:]
                elif csv_file == csv_files[-1]:
                    data = data[:to_record_info.file_record_id]
                else:
                    data = data[:]
                data_collection.append(data)
            
            df = pd.concat(data_collection)
            batch = self.perform_preprocessing(df)
            batch = batch.reshape([self.batch_size, self.window_size, self.feature_dim, 1])

        batch = np.asarray(batch).astype('float32')
        return batch, batch
    
    def get_file_path(self, index):
        return self.file_names[0]
    
    @staticmethod
    def perform_preprocessing(df):
        df = df.fillna(0).to_numpy()[:, 1:] 
        df /= np.max(np.abs(df), axis=0)
        return df
              
    @staticmethod
    def extract_number_of_records(meta_info_file_path):
        with open(Path(meta_info_file_path), "r") as f:
            text = f.read()
        return int(text.split('\n')[1].split('=')[1])
    
    @staticmethod
    def download_file(bucket_name, file_path, local_output_path):
        s3 = boto3.resource('s3')
        file_name = file_path.split('/')[-1]
        try:
            s3.Bucket(bucket_name).download_file(
                str(file_path), str(Path(local_output_path, file_name))
            )
        except ClientError as e:
            if e.response['Error']['Code'] == "404":
                print("The object does not exist.")
            else:
                raise

        
                   
def _parse_args():
    parser = argparse.ArgumentParser()

    # Data, model, and output directories
    # model_dir is always passed in from SageMaker. By default this is a S3 path under the default bucket.
    parser.add_argument('--model_dir', type=str)
    parser.add_argument('--sm-model-dir', type=str, default=os.environ.get('SM_MODEL_DIR'))
    parser.add_argument('--train', type=str, default=os.environ.get('SM_CHANNEL_TRAINING'))
    parser.add_argument('--hosts', type=list, default=json.loads(os.environ.get('SM_HOSTS')))
    parser.add_argument('--current-host', type=str, default=os.environ.get('SM_CURRENT_HOST'))
    parser.add_argument(
        '--epochs',
        type=int,
        default=10,
        help='The number of steps to use for training.')
    parser.add_argument(
        '--batch-size',
        type=int,
        default=128,
        help='Batch size for training.')
    parser.add_argument(
        '--window-size',
        type=int,
        default=8,
        help='Window size - number of records to process as one.')

    return parser.parse_known_args()


if __name__ == "__main__":
    args, unknown = _parse_args()
    print(args)
    local_train_data_path = args.train
    train_data_file_list = sorted(
        list(Path(local_train_data_path).glob('**/*.csv')), 
        key=lambda file_path: file_path.stem
    )
    data_generator = DataGeneratorFromCSV(
        train_data_file_list, 
        window_size=args.window_size, 
        feature_dim=1600, 
        batch_size=args.batch_size
    )
    
    autoencoder = model(
        data_generator, 
        data_generator, 
        args.epochs, 
        window_size=args.window_size, 
        feature_dim=1600, 
        batch_size=args.batch_size
    )

    if args.current_host == args.hosts[0]:
        # save model to an S3 directory with version number '00000001' in Tensorflow SavedModel Format
        # To export the model as h5 format use model.save('my_model.h5')
        autoencoder.save(os.path.join(args.sm_model_dir, '000000001'))
