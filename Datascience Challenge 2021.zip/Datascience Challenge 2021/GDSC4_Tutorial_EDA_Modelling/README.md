# Readme

## Setup
In order to setup for the tutorial these few steps need to be executed:
* Upload the zip file *GDSC4_Tutorial_EDA_Modelling.zip* to your SageMaker Studio instance
* Open a terminal and execute 
    * `sudo yum install -y unzip` to install *unzip*
    * `unzip GDSC4_Tutorial_EDA_Modelling.zip` to unzip the archive
    
## Tutorial Walkthrough
For the tutorial open the notebook file *GDSC - EDA and Basic Modelling.ipynb* and proceed from there.


