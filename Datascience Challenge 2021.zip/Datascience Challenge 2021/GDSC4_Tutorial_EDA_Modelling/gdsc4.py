#!/usr/bin/env python3
#
# This is a wrapper script for GDSC4 API.
# Version: 1.0
#

import json
import logging
import math
import os
from typing import List

import requests


class SubmissionMetadata(object):
    def __init__(self, metadata: dict):
        self.number_of_entries = metadata["number_of_entries"]
        self.number_of_pages = metadata["number_of_pages"]
        self.submission_id = metadata["submission_id"]
        self.uuid = metadata["uuid"]
        self.pages = metadata["pages"].split(",")

    def __repr__(self):
        return (
            "<SubmissionMetadata("
            + ", ".join(
                [
                    f"number_of_entries: {self.number_of_entries}",
                    f"number_of_pages: {self.number_of_pages}",
                    f"submission_id: {self.submission_id}",
                    f"uuid: {self.uuid}",
                    f"pages: {self.pages}",
                ]
            )
            + ")>"
        )


class Token(object):
    logger = logging.getLogger(__name__)

    def __init__(self, token: str = None):

        token_body = os.getenv("TOKEN")
        token_path = os.getenv("TOKEN_PATH")

        if token:
            self.token = token
        elif token_path:
            try:
                with open(token_path, "rb") as f:
                    self.token = f.read().decode("utf-8").strip()
            except Exception as ex:
                raise Exception(f"Can't read token from file: {ex}")
        elif token_body:
            self.token = token_body
        else:
            raise Exception(
                "Neither TOKEN nor TOKEN_PATH environment variables seem to be set.",
                "Also, no token string was passed.",
                "Make sure that at leas one is set",
            )

        self.logger.debug(self)

    def get(self):
        return self.token

    def __repr__(self):
        return f"<Token({self.token})>"


class Client(object):
    logger = logging.getLogger(__name__)

    def __init__(self, token: Token = None):
        api_root = "https://gdsc2021.if0.eu"
        self.page_size = 100000

        if token:
            self.token = token
        else:
            self.token = Token().get()

        self.headers_base = {"Accept": "application/json", "Authorization": f"Baerer {self.token}"}

        self.headers_post = self.headers_base.copy()
        self.headers_post["Content-Type"] = "application/json"
        self.url_submission = f"{api_root}/submission"
        self.url_submissions = f"{api_root}/submissions/metadata"

    def _chunks(self, list_to_chunk: list, number_of_chunks: int):
        """Yield successive number_of_chunks-sized chunks from list_to_chunk."""
        for i in range(0, len(list_to_chunk), number_of_chunks):
            yield list_to_chunk[i : i + number_of_chunks]

    def _post(self, url: str, payload: str) -> requests.models.Response:
        """Post the payload to url

        Args:
            url (str): Url to post to
            payload (str): Payload

        Raises:
            Exception: If failed to post

        Returns:
            requests.models.Response: Response
        """
        try:
            return requests.post(url, data=payload, headers=self.headers_post)
        except Exception as ex:
            raise Exception(f"Can't _post for some reason. Try again: {ex}")

    def _upload_chunk(self, chunk: list, submission_id: int = None) -> SubmissionMetadata:
        """Upload one chung

        Args:
            chunk (list): List of timestamps to be uploaded
            submission_id (int, optional): Submission id to append to. Defaults to None.

        Raises:
            Exception: Failed to jsonify
            Exception: Failed to upload chunk
            Exception: Failed to create SubmissionMetadata
            Exception: Request was not successful, i.e. !x.ok

        Returns:
            SubmissionMetadata: [description]
        """

        self.logger.debug(f"_upload_chunk: submission_id: {submission_id}")

        try:
            payload = json.dumps(chunk)
        except Exception as ex:
            raise Exception(f"_upload_chunk: Failed to json.dumps: {ex}")

        if submission_id:
            url = f"{self.url_submission}?submission_id={submission_id}&token={self.token}"
        else:
            url = f"{self.url_submission}?token={self.token}"

        self.logger.debug(f"_upload_chunk: url: {url}")

        try:
            x = self._post(url, payload)
        except Exception as ex:
            raise Exception(f"_upload_chunk: Can't upload chunk: {ex}")

        if x.ok:
            try:
                return SubmissionMetadata(x.json())
            except Exception as ex:
                raise Exception(f"_upload_chunk: Can't create SubmissionMetadata: {x.text}, {ex}")
        else:
            raise Exception(f"_upload_chunk: Request failed: {x.text}")

    def put_submission(self, payload: list) -> SubmissionMetadata:
        """Upload data to endpoint

        Args:
            payload (list): List of timestamps

        Raises:
            Exception: Generic exception, if not list was passed
            Exception: Generic exception, when sanity check fails

        Returns:
            SubmissionMetadata: Metadata of the submission
        """

        if type(payload) != list:
            raise Exception(f"put_submission: Expected list, got {type(payload)}")

        payload_len = len(payload)
        number_of_chunks = math.ceil(payload_len / self.page_size)
        self.logger.debug(f"put_submission: payload_len: {payload_len}, number_of_chunks: {number_of_chunks}")

        if number_of_chunks > 1:
            first = True
            submission_id = None
            for chunk in self._chunks(payload, self.page_size):
                if first:
                    returned = self._upload_chunk(chunk)
                    submission_id = returned.submission_id
                    first = False
                else:
                    returned = self._upload_chunk(chunk, submission_id)
        else:
            returned = self._upload_chunk(payload)

        # sanity check
        if returned.number_of_entries != payload_len:
            raise Exception(
                "put_submission: Failed to upload all results.",
                f"Expected: {payload_len}, got: {returned.number_of_entries}",
            )

        return returned

    def _get(self, url: str) -> requests.models.Response:
        """Main wrapper for requests.get.

        Args:
            url (str): Url against which the get method should be used

        Raises:
            Exception: For any failure a generic excetion with description is raised

        Returns:
            requests.models.Response: Requests object
        """

        if "?" not in url:
            url_to_use = f"{url}?token={self.token}"
        else:
            url_to_use = f"{url}&token={self.token}"

        self.logger.debug(f"_get: _url_to_use: {url_to_use}")

        try:
            return requests.get(url_to_use, headers=self.headers_post)
        except Exception as ex:
            raise Exception(f"_get: Failed with url: {url_to_use}. {ex}")

    def _get_submissions(self) -> dict:
        """Gets all submissions in dict format

        Raises:
            Exception: Generic exception with message from the request

        Raises:
            Exception: For any failure a generic excetion with description is raised

        Returns:
            dict: Dictionary with all submissions
        """

        r = self._get(self.url_submissions)
        if not r.ok:
            raise Exception(f"_get_submissions: Failed to _get_submissions: {r.text}")
        return r.json()

    def _get_one_page(self, base_url: str, page: int) -> dict:
        """Return data from endpoints page

        Args:
            base_url (str): Url to endpoint
            page (int): Page to download

        Raises:
            Exception: Generic exception for failed _get method
            Exception: Generic exception for non-successful result

        Returns:
            dict: Generic data from the page, depends on endpoint
        """

        self.logger.debug(f"_get_one_page: base_url: {base_url}, page: {page}")

        try:
            r = self._get(f"{base_url}?page={page}")
        except Exception as ex:
            raise Exception(f"_get_one_page: Requests failed: {ex}")

        if not r.ok:
            raise Exception(f"_get_one_page: Status code: {r.status_code}, payload: {r.text}")

        try:
            return r.json().get("payload")
        except Exception as ex:
            raise Exception(f"_get_one_page: Failed to get payload filed, {ex}")

    def _get_all_pages(self, url: str, list_of_pages: list, number_of_entries: int) -> list:
        """Gets all pages for given url

        Args:
            url (str): Url to the endpoint
            list_of_pages (int): List of pages to iterate through
            number_of_entries (int): Number of entries that are expected. Usually comes from metadata.

        Raises:
            Exception: Generic exception with message

        Returns:
            list: Results containing all pages
        """

        self.logger.debug(
            f"_get_all_pages: number_of_pages: {len(list_of_pages)}, ",
            f"list_of_pages: {list_of_pages}, ",
            f"number_of_entries: {number_of_entries}",
        )

        result = []
        for page in list_of_pages:
            subresult = self._get_one_page(url, page)
            if subresult:
                result = result + subresult
            else:
                raise Exception(f"_get_all_pages: failed to get one subresult, page: {page}. Got: {subresult}")

        # sanity check
        if len(result) != number_of_entries:
            raise Exception(f"_get_all_pages: sanity check failed. Got: {len(result)}, expected: {number_of_entries}")
        return result

    def get_submissions(self) -> List[SubmissionMetadata]:
        """Get all SubmissionMetadata as a list

        Raises:
            Exception: Generic exception with description

        Returns:
            List[SubmissionMetadata]: List with SubmissionMetadata objects
        """
        try:
            return list([SubmissionMetadata(submission) for submission in self._get_submissions()])
        except Exception as ex:
            raise Exception(f"Failed to create get_submissions: {ex}")

    def get_last_submission_metadata(self) -> SubmissionMetadata:
        try:
            return self.get_submissions()[0]
        except Exception as ex:
            raise Exception(f"Can't get_last_submission metadata: {ex}")

    def get_last_submission(self) -> list:
        """Get last submission, i.e. the one with the highest id.

        Note: if during retreival of the pages a new upload happens unexpected results might be returned

        Raises:
            Exception: Generic exception with description

        Returns:
            list: Results
        """

        try:
            submission_metadata = self.get_last_submission_metadata()
        except Exception as ex:
            raise Exception(f"Can't get_last_submission metadata: {ex}")

        try:
            return self._get_all_pages(
                self.url_submission, submission_metadata.pages, submission_metadata.number_of_entries
            )
        except Exception as ex:
            raise Exception(f"Failed to _get_all_pages in get_last_submission: {ex}")

    def get_specific_submission_metadata(self, submission_id: int) -> SubmissionMetadata:
        """Get metadata of a specific submission

        Args:
            submission_id (int): ID of the submission

        Raises:
            Exception: Generic exception with message for failed _get request
            Exception: Generic exception with message for SubmissionMetadata object creation

        Returns:
            SubmissionMetadata: Metadata
        """

        self.logger.debug(f"get_specific_submission_metadata: submission_id: {submission_id}")

        try:
            x = self._get(f"{self.url_submission}/{submission_id}/metadata").json()
        except Exception as ex:
            raise Exception(f"Failed to _get in get_specific_submission_metadata: {ex}")

        try:
            return SubmissionMetadata(x)
        except Exception as ex:
            raise Exception(f"Failed to get_specific_submission_metadata: {ex}")

    def get_specific_submission(self, submission_id: int) -> list:
        """Get content of specific submission

        Args:
            submission_id (int): ID of the submission. Can be found in the metadata

        Raises:
            Exception: Generic exception with description

        Returns:
            list: Results
        """

        url = f"{self.url_submission}/{submission_id}"

        self.logger.debug(f"get_specific_submission_metadata: submission_id: {submission_id}, url: {url}")

        try:
            submission_metadata = self.get_specific_submission_metadata(submission_id)
        except Exception as ex:
            raise Exception(f"get_specific_submission: can't get_specific_submission_metadata: {ex}")

        try:
            return self._get_all_pages(url, submission_metadata.pages, submission_metadata.number_of_entries)
        except Exception as ex:
            raise Exception(f"get_specific_submission: can't _get_all_pages: {ex}")


def line(text: str):
    print(f"{'-'* 10} {text} {'-'* 10}")


if __name__ == "__main__":

    import random
    from datetime import datetime, timedelta
    from pprint import pprint

    logging.basicConfig(format="%(asctime)s %(name)s %(levelname)s %(message)s", level=logging.INFO)
    cli = Client()

    # prepare some data to upload
    somewhere_in_past_datetime = datetime.utcnow() - timedelta(hours=24 * 365 + random.randint(100, 300))
    all_points = []
    for minute in range(1 + random.randint(1, 5)):
        all_points.append(
            datetime.strftime((somewhere_in_past_datetime + timedelta(minutes=minute)), "%Y-%m-%dT%H:%M:00.000Z")
        )

    line("Upload test data")
    upload_summary = cli.put_submission(all_points)
    pprint(upload_summary)

    line("Get metadata of last submission")
    last_submissions_metadata = cli.get_last_submission_metadata()
    pprint(last_submissions_metadata)

    line("Get last submission data")
    last_submission_data = cli.get_last_submission()
    pprint(last_submission_data)
    pprint(f"Number of rows: {len(last_submission_data)}")

    line(f"Read the metadata of just uploaded submission with id {upload_summary.submission_id}")
    submission_one_metadata = cli.get_specific_submission_metadata(upload_summary.submission_id)
    pprint(submission_one_metadata)

    line("Get metadata of all submissions of the upload")
    all_submissions_metadata = cli.get_submissions()
    pprint(all_submissions_metadata)

    line(f"We can also get all data in submission {upload_summary.submission_id}")
    submission_one_data = cli.get_specific_submission(upload_summary.submission_id)
    pprint(submission_one_data)
    pprint(f"Number of rows: {len(submission_one_data)}")
